// Memuat data books yang disimpan dalam bentuk array objek.
const books = [];

module.exports = books;
